#ifndef MENUVUELOXCLIENTE_H_INCLUDED
#define MENUVUELOXCLIENTE_H_INCLUDED
/*
void menuVuelosxCliente(){
    int opc;
    while(true){
        system("cls");
        cout << "MENU VUELOS POR CLIENTE"<<endl;
        cout << "----------------"<<endl;
        cout << "1- "<<endl;
        cout << "2- "<<endl;
        cout << "3- "<<endl;
        cout << "4- "<<endl;
        cout << "5- "<<endl;
        cout << "0- VOLVER AL MENU PRINCIPAL"<<endl;
        cout << "----------------"<<endl;
        cout << "INGRESE UNA OPCION: ";

        cin>>opc;

        system("cls");

        switch(opc){

        case 0:
            return;

        default:
            cout << "LA OPCION INGRESADA ES INCORRECTA, REINTENTE"<<endl;
            system("pause");
            break;
        }
    }
}

*/
#endif // MENUVUELOXCLIENTE_H_INCLUDED
